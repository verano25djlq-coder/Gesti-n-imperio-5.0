# IMPERIO DISCO GESTIÓN — Android (Capacitor + SQLite)

Proyecto preparado para compilar un APK Android mediante GitHub Actions desde un teléfono móvil.

## Qué incluye
- La aplicación web v1.5.3 y sus recursos originales.
- Capacitor para empaquetar la app como Android.
- SQLite local para clientes, documentos y configuración.
- Mantiene la versión web usando IndexedDB cuando se abre en navegador.
- Flujo de compilación automática con GitHub Actions.
- La aplicación conserva exportación e importación manual de respaldo JSON; en Android, la exportación abre el menú nativo para guardar o compartir el archivo.

## Antes de instalar la APK: proteger los datos existentes
1. Abrí la versión web actual (v1.5.3).
2. Entrá en Ajustes / Copia de seguridad y usá **Exportar copia**.
3. Guardá el archivo JSON en el teléfono o Drive.
4. Compilá e instalá la APK.
5. En la APK, entrá en Ajustes / Copia de seguridad y usá **Importar copia**.
6. Seleccioná el JSON exportado. Comprobá clientes, presupuestos y contratos.

**No desinstales ni borres los datos de la versión web anterior hasta comprobar la restauración.** La base de datos del navegador y la base SQLite de la APK son almacenes separados; por eso la migración inicial se hace mediante el respaldo JSON.

## Compilar desde Android usando GitHub
1. Creá un repositorio nuevo en GitHub.
2. Subí a la raíz solamente `Imperio_Disco_Gestion_SOURCE_FIXED.zip` (podés renombrarlo a `Imperio_Disco_Gestion_SOURCE.zip`).
3. En GitHub, elegí **Add file → Create new file**.
4. Como ruta escribí exactamente `.github/workflows/android-apk.yml`.
5. Pegá el contenido del archivo `android-apk.yml` corregido que acompaña esta entrega y confirmá el commit.
6. Abrí **Actions → Compilar APK Android → Run workflow**.
7. Cuando termine correctamente, descargá el artefacto `Imperio-Disco-Gestion-APK` y extraé `app-debug.apk`.

El workflow detecta si el código está dentro del ZIP y lo extrae automáticamente; también funciona si subís los archivos fuente directamente a la raíz.

## Datos técnicos
- Identificador Android: `com.imperiodisco.gestion`
- Nombre visible: `Imperio Disco Gestión`
- Base local: SQLite (tablas clients, documents, settings).
- APK inicial: **debug**, instalable para pruebas; no es una versión firmada de publicación.
- La compilación se realiza en los servidores de GitHub Actions (Ubuntu + Java 21 + Node 22).

## Importante
- Esta primera etapa crea una APK de prueba. Antes de distribuirla, hay que generar una clave de firma y configurar una compilación release.
- No borres la copia JSON hasta verificar que la APK restaura y conserva los datos.
- WhatsApp y otras funciones que dependen de servicios externos requieren conexión a Internet.


## Corrección v1.5.3 — inicialización SQLite
- Crea `clients`, `documents` y `settings` con llamadas SQLite independientes.
- Comprueba la existencia de las tres tablas antes de cargar el panel.
- Actualiza la caché del service worker para evitar servir el JavaScript anterior.
